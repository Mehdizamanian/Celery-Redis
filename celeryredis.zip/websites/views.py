# views.py

from django.shortcuts import render
from django.http import HttpResponse
from .tasks import my_task  # Import your task

def home(request):
    my_task.delay()  # Call the task asynchronously
    return HttpResponse("Well done! If you didn't wait for 10 seconds, it worked.")
