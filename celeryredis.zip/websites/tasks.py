# tasks.py

from celery import shared_task
import time

@shared_task
def my_task():
    time.sleep(3)
    # You can perform other actions here, like writing to a file
    with open('test.txt', 'w') as f:
        f.write("Task completed!")
    return "worked"  # Return a simple string or value


# #running worker on new terminal
# #celery -A your_project_name worker --loglevel=info
